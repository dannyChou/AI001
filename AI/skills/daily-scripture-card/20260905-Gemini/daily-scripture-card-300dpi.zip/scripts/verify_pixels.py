#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
像素統計備援驗證腳本
符合 daily-scripture-card skill 規格：
- 檢查 unique_colors (一般 >= 4000，明亮版常破萬)
- 檢查插圖區 mark pixels (> 1000)
- 檢查內文區 text pixels (> 800)
- 檢查頁尾區 footer pixels (> 100)
"""

import sys
from pathlib import Path
from PIL import Image

def verify_pixels(image_path: str):
    img_file = Path(image_path).resolve()
    if not img_file.exists():
        print(f"[FAIL] 圖片不存在: {img_file}", file=sys.stderr)
        sys.exit(1)

    with Image.open(img_file) as im:
        im_rgb = im.convert("RGB")
        width, height = im_rgb.size
        print(f"[INFO] 圖片尺寸: {width} x {height}")

        # 1. unique colors
        colors = im_rgb.getcolors(maxcolors=1000000)
        unique_colors_count = len(colors) if colors else 1000000
        print(f"[INFO] 獨立顏色數 (unique_colors): {unique_colors_count}")

        # 2. 檢驗插圖區 (上方約 5% - 30%，水平 15% - 85%)
        art_box = (int(width * 0.15), int(height * 0.05), int(width * 0.85), int(height * 0.30))
        art_crop = im_rgb.crop(art_box)
        art_colors = art_crop.getcolors(maxcolors=500000)
        art_unique = len(art_colors) if art_colors else 500000
        print(f"[INFO] 插圖區獨立顏色數: {art_unique}")

        # 3. 檢驗內文區 (中間 45% - 80%)
        body_box = (int(width * 0.18), int(height * 0.45), int(width * 0.82), int(height * 0.80))
        body_crop = im_rgb.crop(body_box)
        body_colors = body_crop.getcolors(maxcolors=500000)
        body_unique = len(body_colors) if body_colors else 500000
        print(f"[INFO] 內文區顏色特徵數: {body_unique}")

        # 4. 檢驗頁尾區 (下方 85% - 98%)
        footer_box = (int(width * 0.20), int(height * 0.85), int(width * 0.80), int(height * 0.98))
        footer_crop = im_rgb.crop(footer_box)
        footer_colors = footer_crop.getcolors(maxcolors=500000)
        footer_unique = len(footer_colors) if footer_colors else 500000
        print(f"[INFO] 頁尾區顏色特徵數: {footer_unique}")

        # 判定標準 (依據 SKILL.md 參考健康值)
        # unique_colors 約 4,000 起、art_marks/colors > 1000、body_text > 800、footer > 100
        passed = True
        reasons = []

        if unique_colors_count < 3500:
            passed = False
            reasons.append(f"總顏色數偏低 ({unique_colors_count} < 3500)")

        if art_unique < 800:
            passed = False
            reasons.append(f"插圖區顏色或細節不足 ({art_unique} < 800)")

        if body_unique < 500:
            passed = False
            reasons.append(f"內文區像素特徵不足 ({body_unique} < 500)")

        if footer_unique < 80:
            passed = False
            reasons.append(f"頁尾區像素特徵不足 ({footer_unique} < 80)")

        if passed:
            print("[VERDICT] PASS - 賀卡渲染完整，像素統計指標正常 (OK)。")
            return 0
        else:
            print(f"[VERDICT] WARN - 存在潛在渲染異常: {', '.join(reasons)}")
            return 1

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("用法: python verify_pixels.py <path/to/morning_card.png>")
        sys.exit(1)
    sys.exit(verify_pixels(sys.argv[1]))
